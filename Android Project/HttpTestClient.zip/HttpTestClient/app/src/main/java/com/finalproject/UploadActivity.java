package com.finalproject;


import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;


import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import static android.graphics.Bitmap.createBitmap;
import static android.graphics.Bitmap.createScaledBitmap;

public class UploadActivity extends Activity {

	private MenuItem item;
	private String url = "http://shinji.us.to:8080/android/upload.php";
	//TextView textTargetUri;
	ImageView targetImage;
	String filePath;
	private Uri targetUri;
	private Bitmap bitmap;
	private Bitmap bitmap1;
	private Bitmap bitmap2;
	private Bitmap bitmap3;
	private Bitmap bitmap4;
	private Bitmap bitmapClone;
	TextView heightUndWidth;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_upload);
		
		//final EditText edtTxt1 = (EditText) findViewById(R.id.editTextUpl1);
		final EditText edtTxt2 = (EditText) findViewById(R.id.editTextUpl2);
		Button btnUpl = (Button) findViewById(R.id.upload);


		
		btnUpl.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//String param1 = edtTxt1.getText().toString();
				String param2 = edtTxt2.getText().toString();
				
				item.setActionView(R.layout.progress);
				SendHttpRequestTask t = new SendHttpRequestTask();
				
				String[] params = new String[]{url, param2};
				t.execute(params);
			}
		});
		//super.onCreate(savedInstanceState);
		//setContentView(R.layout.main);
		Button buttonLoadImage = (Button)findViewById(R.id.loadimage);
		//textTargetUri = (TextView)findViewById(R.id.targeturi);
		targetImage = (ImageView)findViewById(R.id.targetimage);

		buttonLoadImage.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Intent.ACTION_PICK,
						android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				startActivityForResult(intent, 0);
			}});

	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK){
			targetUri = data.getData();
			filePath = targetUri.toString();
			//textTargetUri.setText(targetUri.toString());
			//Bitmap bitmap;
			try {
				bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(targetUri));

				int height = bitmap.getHeight();
				int width = bitmap.getWidth();

				if (height > width)
				{
					int sizeToCut = height - width;
					bitmap = createBitmap(bitmap, 0, sizeToCut/2, width, width );

					//bitmap1 = createBitmap(bitmap, 0, 0, width/2, width/2);
					//bitmap2 = createBitmap(bitmap, width/2, 0, width/2, width/2);
					//bitmap3 = createBitmap(bitmap, 0, width/2, width/2, width/2);
					//bitmap4 = createBitmap(bitmap, width/2, width/2, width/2, width/2);
				}
				else {
					int sizeToCut = width - height;
					bitmap = createBitmap(bitmap, sizeToCut/2, 0, height, height);

					//bitmap1 = createBitmap(bitmap, 0, 0, height / 2, height / 2);
					//bitmap2 = createBitmap(bitmap, height / 2, 0, height / 2, height / 2);
					//bitmap3 = createBitmap(bitmap, 0, height / 2, height / 2, height / 2);
					//bitmap4 = createBitmap(bitmap, height / 2, height / 2, height / 2, height / 2);
				}

				//Bitmap bitmapClone = bitmap.copy(bitmap.getConfig(), true);
				bitmap = createScaledBitmap(bitmap, 896, 896, false);

				bitmapClone = createScaledBitmap(bitmap, 448,448,false);

				bitmap1 = createScaledBitmap(bitmapClone, 224, 224, false);

				bitmap2 = createScaledBitmap(bitmap1, 112, 112, false);

				bitmap3 = createScaledBitmap(bitmap2, 56, 56, false);

				bitmap4 = createScaledBitmap(bitmap3, 28, 28, false);

				targetImage.setImageBitmap(bitmap4);

				//makeHuWStr(height, width);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		item = menu.getItem(0);
		return true;
	}

	public void makeHuWStr(int height, int width){
		String heightUndWidthStr = ("Height = " + height + "\nWidth = " + width);
		heightUndWidth.setText(heightUndWidthStr);

	}


	private class SendHttpRequestTask extends AsyncTask<String, Void, String> {
		String data1;
		@Override
		protected String doInBackground(String... params) {



			String url = params[0];
			//String param1 = params[1];
			String param2 = params[1];
			//Bitmap bitmap;


			/*ByteArrayOutputStream baos = new ByteArrayOutputStream();
			bitmap.compress(CompressFormat.PNG, 0, baos);

			ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
			bitmap1.compress(CompressFormat.PNG, 0, baos1);

			ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
			bitmap2.compress(CompressFormat.PNG, 0, baos2);

			ByteArrayOutputStream baos3 = new ByteArrayOutputStream();
			bitmap3.compress(CompressFormat.PNG, 0, baos3);*/

			ByteArrayOutputStream baos4 = new ByteArrayOutputStream();
			bitmap4.compress(CompressFormat.PNG, 0, baos4);

			/*ByteArrayOutputStream baos5 = new ByteArrayOutputStream();
			bitmapClone.compress(CompressFormat.PNG, 0, baos5);*/

	
			try {
				HttpClient client = new HttpClient(url);
				client.connectForMultipart();
				//client.addFormPart("param1", param1);
				client.addFormPart("param2", param2);
				//client.addFilePart("file", param2 + "Orig.png", baos.toByteArray());
				//client.addFilePart("file1", param2 + "1.png", baos1.toByteArray());
				//client.addFilePart("file2", param2 + "2.png", baos2.toByteArray());
				//client.addFilePart("file3", param2 + "3.png", baos3.toByteArray());
				client.addFilePart("file", param2 + ".png", baos4.toByteArray());
				//client.addFilePart("file5", param2 + "Scale.png", baos5.toByteArray());

				client.finishMultipart();
				data1 = client.getResponse();
			}
			catch(Throwable t) {
				t.printStackTrace();
			}
			
			return null;
		}



		@Override
		protected void onPostExecute(String data) {			
			item.setActionView(null);

			TextView heightUndWidth = (TextView) findViewById(R.id.heightUndWidth);

			heightUndWidth.setText(data1);

			
		}
		
		
		
	}


}
